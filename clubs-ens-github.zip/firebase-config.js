// Colle ici la configuration de ton application web Firebase
// (Paramètres du projet > Général > Tes applications > Configuration SDK).
export const firebaseConfig = {
  apiKey: "COLLE_TA_CLE_ICI",
  authDomain: "TON-PROJET.firebaseapp.com",
  projectId: "TON-PROJET",
  appId: "COLLE_TON_APP_ID_ICI"
};
